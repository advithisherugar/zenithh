
import { GoogleGenAI, Type } from "@google/genai";
import { Habit, Todo } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAIInsights = async (habits: Habit[], todos: Todo[]) => {
  try {
    const habitSummary = habits.map(h => `${h.name} (${h.category}): ${h.completedDates.length} completions`).join(', ');
    const todoSummary = todos.map(t => `${t.text} (${t.completed ? 'Done' : 'Pending'})`).join(', ');

    const prompt = `Analyze my progress and provide self-improvement coaching.
    Current Habits: ${habitSummary || 'None set yet'}
    Recent Tasks: ${todoSummary || 'None set yet'}
    
    Provide a structured JSON response with a motivational summary, 3 specific tips for improvement, and a recommended area of focus for the next 7 days.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            tips: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            focusArea: { type: Type.STRING }
          },
          required: ["summary", "tips", "focusArea"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("AI Insights Error:", error);
    return {
      summary: "I'm having trouble analyzing your data right now, but keep pushing forward!",
      tips: ["Stay consistent", "Review your goals daily", "Ensure you get enough sleep"],
      focusArea: "Consistency"
    };
  }
};
