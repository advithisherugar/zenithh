
import React from 'react';
import { Droplets, Plus, Minus } from 'lucide-react';
import { WaterLog } from '../types';

interface WaterTrackerProps {
  logs: WaterLog[];
  onUpdate: (amount: number) => void;
}

const WaterTracker: React.FC<WaterTrackerProps> = ({ logs, onUpdate }) => {
  const today = new Date().toISOString().split('T')[0];
  const todayLog = logs.find(l => l.date === today) || { date: today, amount: 0, goal: 2000 };
  
  const percentage = Math.min(100, (todayLog.amount / todayLog.goal) * 100);

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm overflow-hidden relative">
      <div className="relative z-10">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-slate-800 flex items-center">
            <Droplets className="w-5 h-5 text-blue-500 mr-2" />
            Hydration
          </h3>
          <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
            Goal: {todayLog.goal}ml
          </span>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <div className="text-3xl font-bold text-slate-900">{todayLog.amount}ml</div>
            <p className="text-sm text-slate-500">{percentage.toFixed(0)}% of daily goal</p>
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={() => onUpdate(-250)}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-400"
            >
              <Minus className="w-5 h-5" />
            </button>
            <button 
              onClick={() => onUpdate(250)}
              className="p-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors shadow-lg shadow-blue-200"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Water wave background effect */}
      <div 
        className="absolute bottom-0 left-0 w-full bg-blue-400/10 transition-all duration-700 ease-out"
        style={{ height: `${percentage}%` }}
      />
    </div>
  );
};

export default WaterTracker;
