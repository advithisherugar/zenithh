
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Habit } from '../types';

interface ProgressChartProps {
  habits: Habit[];
}

const ProgressChart: React.FC<ProgressChartProps> = ({ habits }) => {
  const data = habits.map(h => ({
    name: h.name.length > 10 ? h.name.substring(0, 10) + '...' : h.name,
    completions: h.completedDates.length,
  }));

  const colors = ['#6366f1', '#8b5cf6', '#d946ef', '#ec4899', '#f43f5e', '#f97316'];

  if (habits.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-400">
        <p>No habit data to visualize yet.</p>
        <p className="text-xs">Start completing habits to see your chart grow!</p>
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
        <XAxis 
          dataKey="name" 
          axisLine={false} 
          tickLine={false} 
          tick={{ fill: '#94a3b8', fontSize: 12 }} 
        />
        <YAxis 
          axisLine={false} 
          tickLine={false} 
          tick={{ fill: '#94a3b8', fontSize: 12 }}
        />
        <Tooltip 
          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
          cursor={{ fill: '#f8fafc' }}
        />
        <Bar dataKey="completions" radius={[6, 6, 0, 0]}>
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

export default ProgressChart;
