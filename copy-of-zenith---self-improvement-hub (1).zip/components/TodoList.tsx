
import React, { useState, useRef, useMemo } from 'react';
import { Todo } from '../types';
import { Plus, Check, Trash2, ListChecks, Target } from 'lucide-react';

interface TodoListProps {
  todos: Todo[];
  setTodos: React.Dispatch<React.SetStateAction<Todo[]>>;
  userId: string;
  compact?: boolean;
}

const TodoList: React.FC<TodoListProps> = ({ todos, setTodos, userId, compact = false }) => {
  const [newTodo, setNewTodo] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  
  // Achievement sound URL
  const SUCCESS_SOUND = 'https://assets.mixkit.co/active_storage/sfx/2013/success-1-6297.wav';

  const playSuccessSound = () => {
    const audio = new Audio(SUCCESS_SOUND);
    audio.volume = 0.4;
    audio.play().catch(e => console.debug('Audio play blocked or failed', e));
  };

  const progress = useMemo(() => {
    if (todos.length === 0) return 0;
    const completed = todos.filter(t => t.completed).length;
    return Math.round((completed / todos.length) * 100);
  }, [todos]);

  const completedCount = todos.filter(t => t.completed).length;
  const totalCount = todos.length;

  const addTodo = () => {
    if (!newTodo.trim()) return;
    const todo: Todo = {
      id: crypto.randomUUID(),
      userId,
      text: newTodo,
      completed: false,
      priority,
      createdAt: new Date().toISOString(),
    };
    setTodos([todo, ...todos]);
    setNewTodo('');
  };

  const toggleTodo = (id: string) => {
    setTodos(prev => prev.map(t => {
      if (t.id === id) {
        const nextState = !t.completed;
        if (nextState) playSuccessSound();
        return { ...t, completed: nextState };
      }
      return t;
    }));
  };

  const deleteTodo = (id: string) => {
    setTodos(todos.filter(t => t.id !== id));
  };

  return (
    <div className={`bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-slate-800 transition-colors ${compact ? 'p-6' : 'p-10'}`}>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Task Center</h2>
          <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mt-1">Manage your daily objectives</p>
        </div>
        <div className="text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30 p-3 rounded-2xl">
          <ListChecks className="w-6 h-6" />
        </div>
      </div>

      {!compact && (
        <div className="flex flex-col space-y-4 mb-10">
          <div className="flex space-x-3">
            <input
              type="text"
              placeholder="What's the next objective?"
              value={newTodo}
              onChange={(e) => setNewTodo(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addTodo()}
              className="flex-1 px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-[1.25rem] focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-400 font-medium"
            />
            <button
              onClick={addTodo}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-[1.25rem] transition-all font-black uppercase tracking-widest text-xs shadow-xl shadow-indigo-500/20 active:scale-95"
            >
              Add
            </button>
          </div>
          <div className="flex items-center space-x-6 px-2">
            <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">Priority:</span>
            <div className="flex space-x-3">
              {(['low', 'medium', 'high'] as const).map((p) => (
                <label key={p} className="flex items-center cursor-pointer group">
                  <input 
                    type="radio" 
                    name="priority" 
                    checked={priority === p} 
                    onChange={() => setPriority(p)}
                    className="hidden" 
                  />
                  <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border ${
                    priority === p 
                      ? p === 'high' ? 'bg-red-500 text-white border-red-500' : p === 'medium' ? 'bg-yellow-500 text-white border-yellow-500' : 'bg-green-500 text-white border-green-500'
                      : 'bg-transparent text-slate-400 dark:text-slate-600 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}>
                    {p}
                  </span>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Task Progress Bar - User Request: Right above the task list section */}
      {totalCount > 0 && (
        <div className="mb-8 p-6 bg-slate-50 dark:bg-slate-800/30 rounded-3xl border border-slate-100 dark:border-slate-800">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center space-x-2">
              <Target className="w-4 h-4 text-indigo-500" />
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">Current Task Efficiency</span>
            </div>
            <span className="text-sm font-black text-indigo-600 dark:text-indigo-400">{progress}%</span>
          </div>
          <div className="h-3 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-1000 ease-out rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="mt-3 flex justify-between items-center">
             <p className="text-[9px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
               {completedCount} OF {totalCount} OBJECTIVES CLEARED
             </p>
             {progress === 100 && (
               <span className="text-[9px] font-black text-green-500 uppercase tracking-widest flex items-center">
                 <Check className="w-3 h-3 mr-1" /> All tasks completed
               </span>
             )}
          </div>
        </div>
      )}

      <div className="space-y-3">
        {todos.length === 0 ? (
          <div className="text-center py-16 bg-slate-50/50 dark:bg-slate-800/20 rounded-[2rem] border-2 border-dashed border-slate-100 dark:border-slate-800">
            <p className="text-slate-400 dark:text-slate-600 font-bold italic">"Your future is created by what you do today."</p>
            <p className="text-[10px] text-slate-300 dark:text-slate-700 font-black uppercase tracking-widest mt-2">No active tasks</p>
          </div>
        ) : (
          todos.map((todo) => (
            <div
              key={todo.id}
              className={`flex items-center justify-between p-5 rounded-[1.5rem] border transition-all duration-300 ${
                todo.completed 
                  ? 'bg-slate-50/50 dark:bg-slate-900/50 border-transparent opacity-60' 
                  : 'bg-white dark:bg-slate-800/40 border-slate-100 dark:border-slate-800 hover:shadow-xl hover:shadow-indigo-500/5 group'
              }`}
            >
              <div className="flex items-center space-x-5">
                <button
                  onClick={() => toggleTodo(todo.id)}
                  className={`w-7 h-7 rounded-xl border-2 flex items-center justify-center transition-all duration-500 ${
                    todo.completed 
                      ? 'bg-indigo-500 border-indigo-500 text-white scale-90' 
                      : 'border-slate-200 dark:border-slate-700 hover:border-indigo-500 dark:hover:border-indigo-400'
                  }`}
                >
                  {todo.completed && <Check className="w-5 h-5" />}
                </button>
                <div>
                  <p className={`font-bold transition-all ${todo.completed ? 'text-slate-400 dark:text-slate-600 line-through decoration-indigo-500/30' : 'text-slate-800 dark:text-slate-100'}`}>
                    {todo.text}
                  </p>
                  <div className="flex items-center space-x-3 mt-1.5">
                    <div className="flex items-center space-x-1.5">
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        todo.priority === 'high' ? 'bg-red-500' : todo.priority === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                      }`} />
                      <span className="text-[9px] text-slate-400 dark:text-slate-500 uppercase font-black tracking-[0.1em]">{todo.priority}</span>
                    </div>
                    <span className="text-[9px] text-slate-300 dark:text-slate-600 font-bold uppercase tracking-tighter">Added {new Date(todo.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => deleteTodo(todo.id)}
                className="text-slate-200 dark:text-slate-700 hover:text-red-500 dark:hover:text-red-400 transition-all opacity-0 group-hover:opacity-100 p-2"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default TodoList;
