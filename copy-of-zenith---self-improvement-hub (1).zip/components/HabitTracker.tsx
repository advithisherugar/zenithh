
import React, { useState } from 'react';
import { Habit } from '../types';
import { Plus, Check, Flame, Trash2 } from 'lucide-react';

interface HabitTrackerProps {
  habits: Habit[];
  setHabits: React.Dispatch<React.SetStateAction<Habit[]>>;
  userId: string;
  compact?: boolean;
}

const HabitTracker: React.FC<HabitTrackerProps> = ({ habits, setHabits, userId, compact = false }) => {
  const [newHabitName, setNewHabitName] = useState('');
  const [newCategory, setNewCategory] = useState('Personal');

  const addHabit = () => {
    if (!newHabitName.trim()) return;
    const newHabit: Habit = {
      id: crypto.randomUUID(),
      userId,
      name: newHabitName,
      category: newCategory,
      completedDates: [],
      streak: 0,
    };
    setHabits([...habits, newHabit]);
    setNewHabitName('');
  };

  const toggleHabit = (id: string) => {
    const today = new Date().toISOString().split('T')[0];
    setHabits(habits.map(h => {
      if (h.id === id) {
        const isCompleted = h.completedDates.includes(today);
        let newDates = isCompleted 
          ? h.completedDates.filter(d => d !== today)
          : [...h.completedDates, today];
        
        const newStreak = isCompleted ? Math.max(0, h.streak - 1) : h.streak + 1;
        
        return { ...h, completedDates: newDates, streak: newStreak };
      }
      return h;
    }));
  };

  const deleteHabit = (id: string) => {
    setHabits(habits.filter(h => h.id !== id));
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className={`bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 transition-colors ${compact ? 'p-6' : 'p-8'}`}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Habit Tracker</h2>
        {!compact && <span className="text-xs font-semibold px-2 py-1 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-md uppercase">Consistency is Key</span>}
      </div>

      {!compact && (
        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 mb-8">
          <input
            type="text"
            placeholder="New Habit (e.g., Meditation)"
            value={newHabitName}
            onChange={(e) => setNewHabitName(e.target.value)}
            className="flex-1 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-400"
          />
          <select 
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            className="px-4 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-xl outline-none"
          >
            <option>Personal</option>
            <option>Health</option>
            <option>Learning</option>
            <option>Career</option>
          </select>
          <button
            onClick={addHabit}
            className="bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-xl transition-colors shadow-lg shadow-indigo-500/20"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>
      )}

      <div className="space-y-3">
        {habits.length === 0 ? (
          <p className="text-slate-400 dark:text-slate-500 text-center py-8">No habits yet. Start your journey today!</p>
        ) : (
          habits.map((habit) => {
            const isDoneToday = habit.completedDates.includes(today);
            return (
              <div
                key={habit.id}
                className="group flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-xl hover:bg-white dark:hover:bg-slate-800 hover:shadow-md transition-all"
              >
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => toggleHabit(habit.id)}
                    className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                      isDoneToday ? 'bg-green-500 border-green-500 text-white' : 'border-slate-300 dark:border-slate-600 group-hover:border-indigo-500'
                    }`}
                  >
                    {isDoneToday && <Check className="w-5 h-5" />}
                  </button>
                  <div>
                    <h3 className={`font-semibold ${isDoneToday ? 'text-slate-400 dark:text-slate-500 line-through' : 'text-slate-800 dark:text-slate-200'}`}>
                      {habit.name}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{habit.category}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex items-center text-orange-500 font-bold space-x-1">
                    <Flame className="w-4 h-4" />
                    <span className="text-sm">{habit.streak}</span>
                  </div>
                  <button
                    onClick={() => deleteHabit(habit.id)}
                    className="text-slate-300 dark:text-slate-600 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default HabitTracker;
