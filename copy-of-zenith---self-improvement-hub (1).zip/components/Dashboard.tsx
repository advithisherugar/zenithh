
import React, { useState, useEffect, useMemo } from 'react';
import { User, Habit, Todo, WaterLog, CalendarEvent, MoodLog } from '../types';
import TodoList from './TodoList';
import AIInsights from './AIInsights';
import CalendarView from './CalendarView';
import ColoringBook from './ColoringBook';
import { 
  LayoutDashboard, 
  CheckSquare, 
  BrainCircuit, 
  LogOut, 
  Calendar as CalendarIcon, 
  Flame, 
  Zap,
  Quote,
  ArrowRight,
  Sparkles,
  Trophy,
  Activity,
  Sun,
  Moon,
  Palette,
  Target
} from 'lucide-react';

interface DashboardProps {
  user: User;
  onLogout: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onLogout, isDarkMode, toggleTheme }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'todos' | 'calendar' | 'ai' | 'coloring'>('overview');
  const [habits, setHabits] = useState<Habit[]>([]);
  const [todos, setTodos] = useState<Todo[]>([]);
  const [waterLogs, setWaterLogs] = useState<WaterLog[]>([]);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [moods, setMoods] = useState<MoodLog[]>([]);
  const [xp, setXp] = useState(user.xp || 0);
  const [level, setLevel] = useState(user.level || 1);

  const storageKey = `zenith_data_v4_${user.id}`;

  useEffect(() => {
    const saved = localStorage.getItem(storageKey);
    if (saved) {
      const parsed = JSON.parse(saved);
      setHabits(parsed.habits || []);
      setTodos(parsed.todos || []);
      setWaterLogs(parsed.waterLogs || []);
      setEvents(parsed.events || []);
      setMoods(parsed.moods || []);
      setXp(parsed.xp || 0);
      setLevel(parsed.level || 1);
    }
  }, [user.id]);

  useEffect(() => {
    localStorage.setItem(storageKey, JSON.stringify({ habits, todos, waterLogs, events, moods, xp, level }));
  }, [habits, todos, waterLogs, events, moods, xp, level]);

  const today = new Date().toISOString().split('T')[0];

  const taskProgress = useMemo(() => {
    if (todos.length === 0) return 0;
    const completed = todos.filter(t => t.completed).length;
    return Math.round((completed / todos.length) * 100);
  }, [todos]);

  const levelProgress = useMemo(() => {
    // Simple level logic: 100 XP per level
    return xp % 100;
  }, [xp]);

  const zenithStreak = useMemo(() => {
    const activityDates = new Set<string>();
    todos.forEach(t => activityDates.add(t.createdAt.split('T')[0]));
    waterLogs.forEach(l => { if (l.amount > 0) activityDates.add(l.date); });
    const sortedDates = Array.from(activityDates).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
    if (sortedDates.length === 0) return 0;
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    if (!activityDates.has(today) && !activityDates.has(yesterday)) return 0;
    let streak = 0;
    let checkDate = activityDates.has(today) ? new Date() : new Date(Date.now() - 86400000);
    while (activityDates.has(checkDate.toISOString().split('T')[0])) {
      streak++;
      checkDate.setDate(checkDate.getDate() - 1);
    }
    return streak;
  }, [todos, waterLogs, today]);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 18) return "Good Afternoon";
    return "Good Evening";
  };

  const motivation = useMemo(() => {
    const quotes = [
      "The secret of getting ahead is getting started.",
      "Don't stop when you're tired. Stop when you're done.",
      "Your future is created by what you do today.",
      "Small steps lead to big changes over time.",
      "Focus on the process, and the results will follow."
    ];
    return quotes[Math.floor(Math.random() * quotes.length)];
  }, [today]);

  const navItems = [
    { id: 'overview', label: 'Home', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'todos', label: 'Tasks', icon: <CheckSquare className="w-5 h-5" /> },
    { id: 'coloring', label: 'Art Lab', icon: <Palette className="w-5 h-5" /> },
    { id: 'calendar', label: 'Calendar', icon: <CalendarIcon className="w-5 h-5" /> },
    { id: 'ai', label: 'AI Coach', icon: <BrainCircuit className="w-5 h-5" /> },
  ];

  return (
    <div className="flex flex-col md:flex-row h-screen bg-[#FDFDFF] dark:bg-slate-950 overflow-hidden font-sans transition-colors duration-300">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-white dark:bg-slate-900 border-r border-slate-100 dark:border-slate-800 flex flex-col h-auto md:h-full z-40">
        <div className="p-8">
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center space-x-2">
              <Zap className="w-6 h-6 text-indigo-600 fill-indigo-600" />
              <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight uppercase">Zenith</h2>
            </div>
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              aria-label="Toggle theme"
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
          
          <nav className="space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`w-full flex items-center space-x-4 px-4 py-3 rounded-2xl transition-all duration-200 ${
                  activeTab === item.id 
                    ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 font-bold' 
                    : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {item.icon}
                <span className="text-sm">{item.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-slate-50 dark:border-slate-800">
          <div className="mb-6 px-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 font-bold text-xs uppercase">
                {user.fullName[0]}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{user.fullName}</p>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-tighter">Level {level}</p>
              </div>
            </div>
            <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
               <div className="h-full bg-indigo-500" style={{ width: `${levelProgress}%` }} />
            </div>
          </div>
          <button onClick={onLogout} className="w-full flex items-center space-x-4 px-4 py-3 rounded-2xl text-slate-400 dark:text-slate-500 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 transition-all font-bold text-xs uppercase tracking-widest">
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto p-8 md:p-20">
          {activeTab === 'overview' ? (
            <div className="space-y-16 animate-in fade-in slide-in-from-bottom-4 duration-1000">
              
              <header className="flex flex-col md:flex-row md:items-end justify-between gap-8">
                <div className="text-center md:text-left">
                  <p className="text-indigo-600 dark:text-indigo-400 font-black text-xs uppercase tracking-widest mb-2">{getGreeting()}</p>
                  <h1 className="text-5xl font-black text-slate-900 dark:text-white mb-4 tracking-tighter leading-tight">
                    Welcome back, <br/>{user.fullName.split(' ')[0]}.
                  </h1>
                  <div className="flex flex-wrap justify-center md:justify-start gap-4">
                    <div className="flex items-center bg-slate-50 dark:bg-slate-900 px-4 py-2 rounded-full border border-slate-100 dark:border-slate-800">
                      <Activity className="w-4 h-4 text-slate-400 mr-2" />
                      <span className="text-xs font-bold text-slate-500 dark:text-slate-400">System Online</span>
                    </div>
                    <div className="flex items-center bg-indigo-50 dark:bg-indigo-900/20 px-4 py-2 rounded-full border border-indigo-100 dark:border-indigo-800/50">
                      <Trophy className="w-4 h-4 text-indigo-500 dark:text-indigo-400 mr-2" />
                      <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">Level {level}</span>
                    </div>
                  </div>
                </div>
              </header>

              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-orange-400 to-indigo-500 rounded-[3rem] blur opacity-25 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-10 rounded-[3rem] shadow-sm flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="text-center md:text-left">
                    <h3 className="text-sm font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] mb-4">Your Momentum</h3>
                    <div className="flex items-center justify-center md:justify-start space-x-4">
                      <div className="w-20 h-20 bg-orange-50 dark:bg-orange-900/20 rounded-3xl flex items-center justify-center">
                        <Flame className="w-12 h-12 text-orange-500 fill-orange-500" />
                      </div>
                      <div>
                        <p className="text-6xl font-black text-slate-900 dark:text-white tracking-tighter">{zenithStreak}</p>
                        <p className="text-xs font-black text-orange-500 uppercase tracking-widest">Day Streak</p>
                      </div>
                    </div>
                  </div>
                  <div className="max-w-[280px] text-center md:text-right">
                    <p className="text-slate-500 dark:text-slate-400 font-medium leading-relaxed italic">
                      "Consistency is the key to unlocking your true potential."
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 dark:bg-slate-800 p-12 rounded-[3rem] text-white relative overflow-hidden">
                 <Quote className="absolute top-8 left-8 w-24 h-24 text-white/5" />
                 <div className="relative z-10 text-center space-y-6">
                    <h4 className="text-indigo-400 font-black text-xs uppercase tracking-widest">Today's Focus</h4>
                    <p className="text-2xl md:text-3xl font-bold tracking-tight leading-snug">
                      "{motivation}"
                    </p>
                    <div className="w-12 h-1 bg-indigo-500 mx-auto rounded-full" />
                 </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <button 
                  onClick={() => setActiveTab('todos')}
                  className="flex items-center justify-between p-8 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[2.5rem] hover:shadow-xl hover:shadow-indigo-500/5 transition-all group"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                      <CheckSquare className="w-6 h-6" />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-black text-slate-900 dark:text-slate-100">Task Center</p>
                      <p className="text-xs text-slate-400 dark:text-slate-500 font-bold">{todos.filter(t => !t.completed).length} pending tasks</p>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-slate-300 dark:text-slate-600 group-hover:translate-x-1 group-hover:text-indigo-500 transition-all" />
                </button>

                <button 
                  onClick={() => setActiveTab('coloring')}
                  className="flex items-center justify-between p-8 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[2.5rem] hover:shadow-xl hover:shadow-indigo-500/5 transition-all group"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-purple-50 dark:bg-purple-900/30 rounded-2xl flex items-center justify-center text-purple-600 dark:text-purple-400">
                      <Palette className="w-6 h-6" />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-black text-slate-900 dark:text-slate-100">Zen Art Lab</p>
                      <p className="text-xs text-slate-400 dark:text-slate-500 font-bold">Unwind and color</p>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-slate-300 dark:text-slate-600 group-hover:translate-x-1 group-hover:text-purple-500 transition-all" />
                </button>
              </div>

              <div className="flex flex-col items-center pt-8">
                <div className="flex items-center space-x-2 text-slate-400 dark:text-slate-500 mb-4">
                  <Sparkles className="w-4 h-4" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Zenith AI Analysis Ready</span>
                </div>
                <button 
                  onClick={() => setActiveTab('ai')}
                  className="px-8 py-4 bg-slate-100 dark:bg-slate-900 hover:bg-indigo-600 dark:hover:bg-indigo-600 hover:text-white rounded-2xl text-[11px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-400 transition-all"
                >
                  Request Morning Strategy
                </button>
              </div>

            </div>
          ) : (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
               {activeTab === 'todos' && <TodoList todos={todos} setTodos={setTodos} userId={user.id} />}
               {activeTab === 'coloring' && <ColoringBook />}
               {activeTab === 'calendar' && <CalendarView events={events} habits={habits} todos={todos} onAddEvent={(d, t) => setEvents([...events, { id: crypto.randomUUID(), date: d, title: t, type: 'note' }])} onDeleteEvent={(id) => setEvents(events.filter(e => e.id !== id))} />}
               {activeTab === 'ai' && <AIInsights habits={habits} todos={todos} />}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
