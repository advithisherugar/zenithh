
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Calendar as CalendarIcon, X } from 'lucide-react';
import { CalendarEvent, Habit, Todo } from '../types';

interface CalendarViewProps {
  events: CalendarEvent[];
  habits: Habit[];
  todos: Todo[];
  onAddEvent: (date: string, title: string) => void;
  onDeleteEvent: (id: string) => void;
}

const CalendarView: React.FC<CalendarViewProps> = ({ events, habits, todos, onAddEvent, onDeleteEvent }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [newEventTitle, setNewEventTitle] = useState('');

  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const totalDays = daysInMonth(year, month);
  const startDay = firstDayOfMonth(year, month);

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  const isToday = (d: number) => {
    const today = new Date();
    return d === today.getDate() && month === today.getMonth() && year === today.getFullYear();
  };

  const getActivityLevel = (d: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const habitCompletions = habits.filter(h => h.completedDates.includes(dateStr)).length;
    const taskCount = todos.filter(t => t.createdAt.startsWith(dateStr)).length;
    return habitCompletions + taskCount;
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm p-6 transition-colors duration-300">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center">
          <CalendarIcon className="w-5 h-5 mr-2 text-indigo-600 dark:text-indigo-400" />
          {monthName} {year}
        </h2>
        <div className="flex space-x-2">
          <button onClick={prevMonth} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-600 dark:text-slate-400 transition-colors">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button onClick={nextMonth} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-600 dark:text-slate-400 transition-colors">
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1 mb-4">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest py-2">
            {day}
          </div>
        ))}
        
        {Array.from({ length: startDay }).map((_, i) => (
          <div key={`empty-${i}`} className="h-12 w-full" />
        ))}

        {Array.from({ length: totalDays }).map((_, i) => {
          const day = i + 1;
          const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const activity = getActivityLevel(day);
          const hasEvents = events.some(e => e.date === dateStr);
          const isSelected = selectedDate === dateStr;
          const currentIsToday = isToday(day);

          return (
            <button
              key={day}
              onClick={() => setSelectedDate(dateStr)}
              className={`relative h-12 w-full rounded-xl flex flex-col items-center justify-center transition-all duration-200 outline-none
                ${currentIsToday 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-indigo-900/20 z-10' 
                  : isSelected
                    ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 ring-2 ring-indigo-500 ring-inset'
                    : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700'
                }
              `}
            >
              <span className={`text-sm ${currentIsToday ? 'font-black' : 'font-bold'}`}>
                {day}
              </span>
              
              <div className="flex space-x-1 mt-1 min-h-[4px]">
                {activity > 0 && (
                  <div className={`w-1 h-1 rounded-full ${currentIsToday ? 'bg-indigo-200' : 'bg-indigo-500 dark:bg-indigo-400'}`} />
                )}
                {hasEvents && (
                  <div className={`w-1 h-1 rounded-full ${currentIsToday ? 'bg-amber-200' : 'bg-amber-500 dark:bg-amber-400'}`} />
                )}
              </div>
            </button>
          );
        })}
      </div>

      {selectedDate && (
        <div className="mt-6 p-5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm">Activities on {selectedDate}</h3>
            <button onClick={() => setSelectedDate(null)} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors">
              <X className="w-4 h-4 text-slate-500 dark:text-slate-400" />
            </button>
          </div>
          
          <div className="space-y-2 mb-4">
            {events.filter(e => e.date === selectedDate).length === 0 ? (
              <p className="text-xs text-slate-400 dark:text-slate-500 italic">No notes for this day.</p>
            ) : (
              events.filter(e => e.date === selectedDate).map(event => (
                <div key={event.id} className="flex justify-between items-center bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700 text-sm shadow-sm group">
                  <span className="text-slate-700 dark:text-slate-200 font-medium">{event.title}</span>
                  <button 
                    onClick={() => onDeleteEvent(event.id)} 
                    className="text-slate-300 dark:text-slate-600 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))
            )}
          </div>

          <div className="flex space-x-2">
            <input 
              type="text" 
              placeholder="Add quick note..."
              className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-500 text-slate-700 dark:text-slate-200"
              value={newEventTitle}
              onChange={(e) => setNewEventTitle(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && (onAddEvent(selectedDate, newEventTitle), setNewEventTitle(''))}
            />
            <button 
              onClick={() => { onAddEvent(selectedDate, newEventTitle); setNewEventTitle(''); }}
              className="bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-xl transition-all shadow-md active:scale-95"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CalendarView;
