
import React, { useState } from 'react';
import { Habit, Todo, AIRecommendation } from '../types';
import { getAIInsights } from '../services/geminiService';
import { Sparkles, RefreshCw, Lightbulb, Zap } from 'lucide-react';

interface AIInsightsProps {
  habits: Habit[];
  todos: Todo[];
}

const AIInsights: React.FC<AIInsightsProps> = ({ habits, todos }) => {
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<AIRecommendation | null>(null);

  const generateInsights = async () => {
    setLoading(true);
    const result = await getAIInsights(habits, todos);
    setRecommendation(result);
    setLoading(false);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 p-8 transition-colors duration-300">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Zenith AI Coach</h2>
          <p className="text-slate-500 dark:text-slate-400">Get personalized insights and improvement tips.</p>
        </div>
        <button
          onClick={generateInsights}
          disabled={loading}
          className="flex items-center justify-center space-x-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 dark:disabled:bg-slate-700 text-white px-6 py-3 rounded-xl transition-all shadow-lg shadow-indigo-500/20"
        >
          {loading ? (
            <RefreshCw className="w-5 h-5 animate-spin" />
          ) : (
            <Sparkles className="w-5 h-5" />
          )}
          <span className="font-semibold">{recommendation ? 'Refresh Coaching' : 'Get Insights'}</span>
        </button>
      </div>

      {!recommendation && !loading && (
        <div className="flex flex-col items-center justify-center py-12 text-center bg-slate-50 dark:bg-slate-800/30 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-700">
          <BrainIcon />
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200 mt-4">AI Coach Ready</h3>
          <p className="text-slate-500 dark:text-slate-400 max-w-sm mt-2">Click the button above to analyze your habits and tasks for personalized self-improvement suggestions.</p>
        </div>
      )}

      {loading && (
        <div className="flex flex-col items-center justify-center py-20">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-indigo-200 dark:border-slate-800 border-t-indigo-600 rounded-full animate-spin"></div>
            <Sparkles className="w-8 h-8 text-indigo-500 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
          </div>
          <p className="mt-6 text-slate-500 dark:text-slate-400 font-medium animate-pulse">Zenith is analyzing your journey...</p>
        </div>
      )}

      {recommendation && !loading && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-indigo-50 to-blue-50 dark:from-indigo-900/10 dark:to-blue-900/10 p-6 rounded-2xl border border-indigo-100 dark:border-indigo-900/30">
            <h4 className="flex items-center text-indigo-800 dark:text-indigo-300 font-bold mb-3">
              <Sparkles className="w-5 h-5 mr-2" />
              Progress Summary
            </h4>
            <p className="text-slate-700 dark:text-slate-300 leading-relaxed italic">"{recommendation.summary}"</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="flex items-center text-amber-600 dark:text-amber-500 font-bold">
                <Lightbulb className="w-5 h-5 mr-2" />
                Actionable Tips
              </h4>
              <ul className="space-y-3">
                {recommendation.tips.map((tip, i) => (
                  <li key={i} className="flex items-start space-x-3 bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 shadow-sm">
                    <span className="flex-shrink-0 w-6 h-6 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-full flex items-center justify-center text-xs font-bold">
                      {i + 1}
                    </span>
                    <span className="text-slate-700 dark:text-slate-300 text-sm leading-snug">{tip}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="flex items-center text-purple-600 dark:text-purple-400 font-bold">
                <Zap className="w-5 h-5 mr-2" />
                Next Area of Focus
              </h4>
              <div className="bg-purple-50 dark:bg-purple-900/10 p-6 rounded-2xl border border-purple-100 dark:border-purple-900/30">
                <p className="text-purple-900 dark:text-purple-300 font-bold text-xl mb-2">{recommendation.focusArea}</p>
                <p className="text-purple-700 dark:text-purple-400/80 text-sm">
                  Concentrate on this area for the next 7 days to see maximum improvement in your self-development journey.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const BrainIcon = () => (
  <div className="w-16 h-16 bg-indigo-100 dark:bg-slate-800 rounded-full flex items-center justify-center transition-colors">
    <svg className="w-10 h-10 text-indigo-600 dark:text-indigo-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
      <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
      <line x1="12" x2="12" y1="19" y2="22" />
    </svg>
  </div>
);

export default AIInsights;
