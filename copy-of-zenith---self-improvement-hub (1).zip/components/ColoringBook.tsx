
import React, { useState, useMemo } from 'react';
import { Palette, Undo2, RotateCcw, Sparkles, Image as ImageIcon } from 'lucide-react';

const COLORS = [
  '#ef4444', '#f97316', '#f59e0b', '#84cc16', '#10b981', '#06b6d4', 
  '#3b82f6', '#6366f1', '#8b5cf6', '#d946ef', '#f43f5e', '#ffffff', '#1e293b'
];

type TemplateId = 'mandala' | 'flower' | 'geometric' | 'butterfly';

const ColoringBook: React.FC = () => {
  const [selectedColor, setSelectedColor] = useState(COLORS[7]); // Indigo
  const [activeTemplate, setActiveTemplate] = useState<TemplateId>('mandala');
  
  // Store filled paths separately for each template
  const [filledData, setFilledData] = useState<Record<TemplateId, Record<string, string>>>({
    mandala: {},
    flower: {},
    geometric: {},
    butterfly: {}
  });

  const handleFill = (pathId: string) => {
    setFilledData(prev => ({
      ...prev,
      [activeTemplate]: {
        ...prev[activeTemplate],
        [pathId]: selectedColor
      }
    }));
  };

  const resetCanvas = () => {
    setFilledData(prev => ({
      ...prev,
      [activeTemplate]: {}
    }));
  };

  const templates: { id: TemplateId, name: string, total: number }[] = [
    { id: 'mandala', name: 'Infinite Mandala', total: 17 },
    { id: 'flower', name: 'Lotus Bloom', total: 13 },
    { id: 'geometric', name: 'Prism Network', total: 9 },
    { id: 'butterfly', name: 'Spirit Wings', total: 5 },
  ];

  const currentFilled = filledData[activeTemplate];
  
  const progress = useMemo(() => {
    const template = templates.find(t => t.id === activeTemplate);
    if (!template) return 0;
    const filledCount = Object.keys(currentFilled).length;
    return Math.min(100, Math.round((filledCount / template.total) * 100));
  }, [activeTemplate, currentFilled]);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-100 dark:border-slate-800 p-8 shadow-sm animate-in fade-in duration-700 transition-colors">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
        <div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white flex items-center">
            <Palette className="w-8 h-8 mr-3 text-purple-500" />
            Zen Art Lab
          </h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Digital mindfulness through colors.</p>
        </div>
        <div className="flex items-center space-x-2">
           <button 
             onClick={resetCanvas}
             className="p-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-all flex items-center space-x-2 text-xs font-bold uppercase tracking-widest"
           >
             <RotateCcw className="w-4 h-4" />
             <span>Reset Canvas</span>
           </button>
        </div>
      </div>

      {/* Image Selection Tabs */}
      <div className="flex overflow-x-auto pb-4 mb-4 gap-4 scrollbar-hide no-scrollbar">
        {templates.map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTemplate(t.id)}
            className={`flex-shrink-0 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${
              activeTemplate === t.id 
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-200 dark:shadow-purple-900/20' 
                : 'bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
            }`}
          >
            {t.name}
          </button>
        ))}
      </div>

      {/* Progress Bar */}
      <div className="mb-8 space-y-2">
        <div className="flex justify-between items-end">
          <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Masterpiece Completion</span>
          <span className="text-sm font-black text-purple-600 dark:text-purple-400">{progress}%</span>
        </div>
        <div className="h-3 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 transition-all duration-500 ease-out rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Color Palette */}
        <div className="lg:col-span-2 order-2 lg:order-1 flex lg:flex-col flex-wrap gap-3 justify-center content-start">
          {COLORS.map((color) => (
            <button
              key={color}
              onClick={() => setSelectedColor(color)}
              className={`w-10 h-10 rounded-xl transition-all border-4 ${
                selectedColor === color ? 'border-indigo-500 scale-110 shadow-lg' : 'border-transparent hover:scale-105'
              }`}
              style={{ backgroundColor: color }}
            />
          ))}
          <div className="mt-4 flex lg:flex-col items-center justify-center p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
            <Palette className="w-3 h-3 mb-1" />
            Active
          </div>
        </div>

        {/* Canvas Area */}
        <div className="lg:col-span-10 order-1 lg:order-2 bg-slate-50 dark:bg-slate-800/30 rounded-[2.5rem] flex items-center justify-center p-6 md:p-12 overflow-hidden border-2 border-dashed border-slate-200 dark:border-slate-700 relative min-h-[400px]">
          
          <svg viewBox="0 0 200 200" className="w-full max-w-[500px] h-auto cursor-pointer drop-shadow-2xl">
            {/* TEMPLATE 1: MANDALA */}
            {activeTemplate === 'mandala' && (
              <>
                <circle cx="100" cy="100" r="20" fill={currentFilled['center'] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill('center')} />
                {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => (
                  <path key={`m1-${i}`} d="M100 80 Q115 60 100 40 Q85 60 100 80" transform={`rotate(${angle}, 100, 100)`} fill={currentFilled[`m1-${i}`] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill(`m1-${i}`)} className="hover:stroke-indigo-400 transition-colors" />
                ))}
                {[22.5, 67.5, 112.5, 157.5, 202.5, 247.5, 292.5, 337.5].map((angle, i) => (
                  <path key={`m2-${i}`} d="M100 70 Q125 40 100 10 Q75 40 100 70" transform={`rotate(${angle}, 100, 100)`} fill={currentFilled[`m2-${i}`] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill(`m2-${i}`)} className="hover:stroke-indigo-400 transition-colors" />
                ))}
              </>
            )}

            {/* TEMPLATE 2: FLOWER */}
            {activeTemplate === 'flower' && (
              <>
                <circle cx="100" cy="100" r="15" fill={currentFilled['core'] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill('core')} />
                {[0, 60, 120, 180, 240, 300].map((angle, i) => (
                  <circle key={`f1-${i}`} cx="100" cy="70" r="25" transform={`rotate(${angle}, 100, 100)`} fill={currentFilled[`f1-${i}`] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill(`f1-${i}`)} className="opacity-70 hover:opacity-100 transition-opacity" />
                ))}
                {[30, 90, 150, 210, 270, 330].map((angle, i) => (
                  <circle key={`f2-${i}`} cx="100" cy="50" r="20" transform={`rotate(${angle}, 100, 100)`} fill={currentFilled[`f2-${i}`] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill(`f2-${i}`)} />
                ))}
              </>
            )}

            {/* TEMPLATE 3: GEOMETRIC */}
            {activeTemplate === 'geometric' && (
              <>
                {[0, 45, 90, 135].map((angle, i) => (
                  <rect key={`g1-${i}`} x="60" y="60" width="80" height="80" transform={`rotate(${angle}, 100, 100)`} fill={currentFilled[`g1-${i}`] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill(`g1-${i}`)} />
                ))}
                {[0, 90, 180, 270].map((angle, i) => (
                  <polygon key={`g2-${i}`} points="100,20 120,50 80,50" transform={`rotate(${angle}, 100, 100)`} fill={currentFilled[`g2-${i}`] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill(`g2-${i}`)} />
                ))}
                <circle cx="100" cy="100" r="10" fill={currentFilled['g3'] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill('g3')} />
              </>
            )}

            {/* TEMPLATE 4: BUTTERFLY */}
            {activeTemplate === 'butterfly' && (
              <>
                <ellipse cx="100" cy="100" rx="5" ry="30" fill={currentFilled['body'] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill('body')} />
                <path d="M105 100 C150 50 180 80 160 130 C140 160 110 130 105 100" fill={currentFilled['w1r'] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill('w1r')} />
                <path d="M95 100 C50 50 20 80 40 130 C60 160 90 130 95 100" fill={currentFilled['w1l'] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill('w1l')} />
                <path d="M105 100 C180 120 180 180 130 190 C90 195 100 130 105 100" fill={currentFilled['w2r'] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill('w2r')} />
                <path d="M95 100 C20 120 20 180 70 190 C110 195 100 130 95 100" fill={currentFilled['w2l'] || 'white'} stroke="#cbd5e1" strokeWidth="0.5" onClick={() => handleFill('w2l')} />
              </>
            )}
          </svg>
          
          <div className="absolute top-4 right-4 flex items-center bg-white/80 dark:bg-slate-900/80 backdrop-blur px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-700 shadow-sm">
            <Sparkles className="w-3 h-3 text-purple-500 mr-2" />
            <span className="text-[10px] font-black uppercase tracking-tighter text-slate-500">{templates.find(t => t.id === activeTemplate)?.name}</span>
          </div>
        </div>
      </div>

      <div className="mt-12 flex flex-col md:flex-row items-center justify-between gap-4 p-6 bg-purple-50 dark:bg-purple-900/10 rounded-[2rem] border border-purple-100 dark:border-purple-800/30">
        <div className="flex items-center space-x-3">
          <Sparkles className="text-purple-500 w-5 h-5" />
          <p className="text-sm font-bold text-purple-900 dark:text-purple-300">Art is therapy. Every stroke clears the mind.</p>
        </div>
        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-purple-400">Zenith Art Protocol Active</p>
      </div>
    </div>
  );
};

export default ColoringBook;
