
import React, { useState } from 'react';
import { User } from '../types';
import { Eye, EyeOff, HelpCircle, ShieldCheck } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [showAccountHint, setShowAccountHint] = useState(false);

  const getStoredUsers = () => JSON.parse(localStorage.getItem('zenith_users') || '[]');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanUsername = username.trim();
    const cleanPassword = password; 

    if (!cleanUsername || !cleanPassword) {
      setError('Please fill in all fields');
      return;
    }

    if (isSignUp && !fullName.trim()) {
      setError('Please enter your full name');
      return;
    }

    const storedUsers = getStoredUsers();

    if (isSignUp) {
      if (storedUsers.some((u: any) => u.username.toLowerCase() === cleanUsername.toLowerCase())) {
        setError('Username already taken. Try logging in!');
        return;
      }
      const newUser: User & { password: string } = {
        id: crypto.randomUUID(),
        username: cleanUsername,
        fullName: fullName.trim(),
        password: cleanPassword,
        joinedAt: new Date().toISOString(),
        xp: 0,
        level: 1
      };
      localStorage.setItem('zenith_users', JSON.stringify([...storedUsers, newUser]));
      onLogin({ id: newUser.id, username: newUser.username, fullName: newUser.fullName, joinedAt: newUser.joinedAt, xp: 0, level: 1 });
    } else {
      const user = storedUsers.find((u: any) => 
        u.username.toLowerCase() === cleanUsername.toLowerCase() && 
        u.password === cleanPassword
      );

      if (user) {
        onLogin({ id: user.id, username: user.username, fullName: user.fullName, joinedAt: user.joinedAt, xp: user.xp || 0, level: user.level || 1 });
      } else {
        setError('Invalid username or password.');
      }
    }
  };

  const existingUsernames = getStoredUsers().map((u: any) => u.username);

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-30 pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-indigo-600/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-purple-600/20 rounded-full blur-[120px]" />
      </div>

      <div className="bg-slate-900/50 backdrop-blur-2xl p-8 md:p-12 rounded-[2.5rem] shadow-2xl w-full max-w-md border border-white/5 relative z-10">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-tr from-indigo-600 to-purple-500 rounded-2xl mb-6 shadow-2xl shadow-indigo-500/40 rotate-3">
             <ShieldCheck className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-black text-white tracking-tighter mb-2">ZENITH</h1>
          <p className="text-slate-400 font-medium">Your personal growth sanctuary.</p>
        </div>

        <div className="flex bg-white/5 p-1 rounded-2xl mb-8 border border-white/5">
          <button 
            onClick={() => { setIsSignUp(false); setError(''); }}
            className={`flex-1 py-3 text-sm font-bold rounded-xl transition-all ${!isSignUp ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Sign In
          </button>
          <button 
            onClick={() => { setIsSignUp(true); setError(''); }}
            className={`flex-1 py-3 text-sm font-bold rounded-xl transition-all ${isSignUp ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Sign Up
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {isSignUp && (
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest ml-1">Identity</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white placeholder:text-slate-600 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                placeholder="Your Full Name"
              />
            </div>
          )}
          
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest ml-1">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white placeholder:text-slate-600 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              placeholder="e.g. zenith_warrior"
            />
          </div>

          <div className="space-y-1.5 relative">
            <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest ml-1">Access Key</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white placeholder:text-slate-600 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                placeholder="••••••••"
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-indigo-400 transition-colors"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl">
              <p className="text-red-400 text-xs font-bold text-center mb-2">{error}</p>
              {!isSignUp && (
                <button 
                  type="button" 
                  onClick={() => setShowAccountHint(!showAccountHint)}
                  className="flex items-center justify-center w-full text-[10px] text-indigo-400 font-bold hover:underline"
                >
                  <HelpCircle size={10} className="mr-1" /> Forgotten your details?
                </button>
              )}
            </div>
          )}

          {showAccountHint && existingUsernames.length > 0 && (
            <div className="p-3 bg-indigo-500/5 rounded-xl border border-indigo-500/10 text-[10px]">
              <p className="text-slate-400 font-bold mb-1 uppercase tracking-tighter">Known accounts on this device:</p>
              <div className="flex flex-wrap gap-1">
                {existingUsernames.map(u => (
                  <span key={u} className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded-md">{u}</span>
                ))}
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-black py-5 rounded-2xl transition-all shadow-2xl shadow-indigo-600/20 active:scale-[0.98] uppercase tracking-widest text-sm"
          >
            {isSignUp ? 'Initiate Journey' : 'Access Dashboard'}
          </button>
        </form>

        <p className="text-center text-slate-600 text-[10px] mt-10 font-bold uppercase tracking-widest">
          End-to-end self-improvement encryption
        </p>
      </div>
    </div>
  );
};

export default Login;
